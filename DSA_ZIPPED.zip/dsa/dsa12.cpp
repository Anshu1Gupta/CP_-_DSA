#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main() {
// int arr[5] ={7,9,1,2,3};
// int min,temp ;
// min =arr[0];
// for (int i = 0; i < 6; i++)
// {
//     if (arr[i] < min){
//         min= arr[i];
//     }
// }
// cout<<min ;



return 0;
}